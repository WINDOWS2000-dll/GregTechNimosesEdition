cDM - carphooon's Dressable Maid　version2.1
by かーふーん



【概要】
これはMinecraft Java EditionのMOD『littleMaidMob』用のマルチモデル、及び専用テクスチャを同梱した拡張パックです。

コンセプトは”着せ替え”です。防具のモデルや材料を変えることで着せ替えが楽しめます。
また『cDM対応』と表示されたテクスチャ/マルチモデルパックを導入することで、服のバリエーションを増やせます。



【内容物】
・cDMB……メイドさん本体のモデルです。複数の胴体パーツ、及び表情を追加します。
・cDMW……防具専用のモデルです。
・cDMWmd…同梱するメイド服のためのモデルです。



【対象環境】
littleMaidMobが動作するMinecraft JE

以下のバージョンでモデル読み込みを確認済みです。
LMM1.6.2
LMM1.6.4
LMMX1.7.10
LMMNX1.8.9
LMRE1.9.4
LMRE1.10.2
LMRE1.12.2peko
LMRE1.12.2firis
LMRB1.16.5Architectury(fabric/forge)
LMRB1.17.1(fabric)

※バージョンによって動作しない機能/未実装の機能が存在しています。同梱の operational_verification.xlsx を御覧ください（ネタバレ防止処理済み）。
※LMRB1.15.2では、モデル読み込みは可能ですが表情が正常に表示されないため、動作対象外としています。
※LMRB1.17.1のforge版は、現在作者が1.17.1のforge環境をつくれない為動作未確認です。多分動くと思います。



【導入方法】

[LMM1.6.2、LMM1.6.4、LMMX1.7.10、LMNX1.8.9、LMRE1.9.4、LMRE1.10.2、LMRE1.12.2peko]
mod本体を導入後、本zipファイルを解凍せずmodsフォルダに入れてください。


[LMRE1.12.2firis]
mod本体を導入後、modsフォルダと同じ場所にあるLittleMaidResourceフォルダに入れてください。
(mod導入に成功していないとLittleMaidResourceフォルダは生成されません)


[LMRB1.16.5Architectury(forge)、LMRB1.16.5Architectury(fabric)、LMRB1.17.1(forge)、LMRB1.17.1(fabric)]
mod本体を導入後、modsフォルダと同じ場所にあるLittleMaidResourceフォルダに入れてください。
(mod導入に成功していないとLittleMaidResourceフォルダは生成されません)



【注意事項】
・マルチモデルのアップデートの際、ワールドにいる前バージョンのメイドさんは【必ず】デフォルトのテクスチャに差し替えてください。
メイドさんの消失やチャンク初期化などの原因になることがあります（特に1.6.2版）。



【利用規約】
・導入は自己責任でお願いします。本パックの導入に起因し利用者に発生する損害に対し、作者が責任を追うことは一切ありません。
・以下を禁止事項とします。
	-商用利用
	-未改造での二次配布
・本パックのモデルの改造は自由です。改造して再配布する場合は、改造元バージョンの本パックのreadmeを同封してください。
・本パックを導入した状態でのMinecraft動画の投稿はご自由に行ってください。
・改造再配布、及び動画投稿の際、作者にご一報いただくととても嬉しいです。



【謝辞】
本マルチモデルの制作にあたり、以下の方々によるマルチモデルより着想を得ました。
・voms氏作『Beverly7』『Chloe2』
・moyu氏作『VOICELOID』『3M』
この場をもってお礼申し上げます。大変ありがとうございました。



【リンク】
Twitter		@carphooon
Discord		carphooon226#4378
メール		carphooon226@protonmail.com
トピック	https://forum.civa.jp/viewtopic.php?f=3&t=57&start=10#p2036
配布場所	https://ux.getuploader.com/cph_LMM/
		https://carphooon.booth.pm/items/2298738





2020/08/02 策定
2020/09/11 改定