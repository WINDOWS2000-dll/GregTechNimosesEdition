cDM - carphooon's Dressable Maid version2.1
by carphooon



[ABOUT]
This is an expansion pack that includes multi-models and exclusive textures for the Minecraft Java Edition mod "littleMaidMob".

The concept of the game is "dress-up". You can change your armour by changing the models and materials used.
You can also increase the variety of your outfits by adding textures and multi-model packs marked "cDM対応(cDM compatible)".


[CONTENTS]
・cDMB……This model is the main body of the maid. Multiple torso parts and facial expressions will be added.
・cDMW……This model is specially designed for protective gear.
・cDMWmd…This is the model for the maid's outfit included in the package.


[REQUIRED]
Minecraft JE with littleMaidMob running

The following versions have been tested for model loading
LMM1.6.2
LMM1.6.4
LMMX1.7.10
LMMNX1.8.9
LMRE1.9.4
LMRE1.10.2
LMRE1.12.2peko
LMRE1.12.2firis
LMRB1.16.5Architectury(fabric/forge)
LMRB1.17.1(fabric)

*There are some features that do not work or are not implemented in some versions. Please refer to operational_verification.xlsx (spoiler protected).
*LMRB1.15.2 does not work because the model can be loaded but the expressions are not displayed correctly.
*The forge version of LMRB 1.17.1 has not been tested yet because the author does not have a forge environment for 1.17.1 at the moment. Well, it will work maybe...


[HOW TO INSTALL]

****for LMM1.6.2、LMM1.6.4、LMMX1.7.10、LMNX1.8.9、LMRE1.9.4、LMRE1.10.2、LMRE1.12.2peko****
After installing the mod itself, please put this zip file into the mods directory without unzipping it.


****for LMRE1.12.2firis****
After installing the mod itself, place it in the LittleMaidResource directory in the same location as the mods directory.
(The LittleMaidResource directory will not be created unless you have successfully installed the mod).



****for LMRB1.16.5Architectury(forge)、LMRB1.16.5Architectury(fabric)、LMRB1.17.1(fabric)****
After installing the mod itself, place it in the LittleMaidResource directory in the same location as the mods directory.
(The LittleMaidResource directory will not be created unless you have successfully installed the mod).


[NOTES]
When updating multi-models, please replace absolutely the previous version's maids in the world with the default textures.
This may cause loss of maids and initialization of chunks (especially in version 1.6.2).



[TERMS OF USE]
Installation is at your own risk. The author will not be held responsible for any damage caused to users as a result of installing this pack.
The following are prohibited
	-Commercial use
	-Secondary distribution in unmodified form
You are free to modify the models in this pack. If you modify and redistribute this pack, please include the README.txt of the original version of this pack.
Please feel free to post Minecraft videos with this pack installed.
We would be very happy if you inform the author when you redistribute or post the video.

If you need anything, please contact me.
I am Japanese. I try to speak English as much as possible, but when you use easy English, I'm so happy :)))



[ACKNOWLEDGEMENTS]
The creation of this multi-model was inspired by the multi-models of the following people
	"Beverly7" "Chloe2"  created by voms
	"VOICELOID" "3M"  created by moyu
Thank you very much!!!!!!!!!



[LINKS]
Twitter		@carphooon
Discord		carphooon226#4378
e-Mail		carphooon226@protonmail.com
Forum		https://forum.civa.jp/viewtopic.php?f=3&t=57&start=10#p2036
Distribution	https://ux.getuploader.com/cph_LMM/
		https://carphooon.booth.pm/items/2298738





2020/08/02 Formulated
2020/09/11 Revisioned
2020/09/21 Translated (by DeepL)